# ABI Compatibility Note

The API defined in these public interfaces MUST retain a stable ABI through
different releases of Mod Engine.